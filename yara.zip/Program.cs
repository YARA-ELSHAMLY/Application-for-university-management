﻿using System;
using System.Collections.Generic;

public abstract class Person
{
    public string Name { get; set; }
    public int Age { get; set; }

    public abstract void DisplayInfo();
}

public interface IEnrollable
{
    void EnrollInCourse(Course course);
}

public class Student : Person, IEnrollable
{
    public Student(string name, int age)
    {
        Name = name;
        Age = age;
    }

    public List<Course> Courses { get; } = new List<Course>();

    public override void DisplayInfo()
    {
        Console.WriteLine($"Student: {Name}, Age: {Age}");
    }

    public void EnrollInCourse(Course course)
    {
        Courses.Add(course);
        Console.WriteLine($"{Name} has enrolled in the course: {course.Name}");
    }
}

public class Course
{
    public string Name { get; set; }
    public string Code { get; set; }

    public Course(string name, string code)
    {
        Name = name;
        Code = code;
    }
}

public class University
{
    public List<Student> Students { get; } = new List<Student>();
    public List<Course> Courses { get; } = new List<Course>();

    public void AddStudent(Student student)
    {
        Students.Add(student);
    }

    public void AddCourse(Course course)
    {
        Courses.Add(course);
    }
}

class Program
{
    static void Main(string[] args)
    {
        University university = new University();

        Student student1 = new Student("yara", 20);
        Student student2 = new Student("malak", 23);

        Course course1 = new Course("Math 109", "MATH109");
        Course course2 = new Course("PAIOLOGY 109", "PAIO109");

        university.AddStudent(student1);
        university.AddStudent(student2);
        university.AddCourse(course1);
        university.AddCourse(course2);

        student1.EnrollInCourse(course1);
        student2.EnrollInCourse(course2);

        Console.WriteLine("University Students:");
        foreach (var student in university.Students)
        {
            student.DisplayInfo();
        }

        Console.WriteLine("University Courses:");
        foreach (var course in university.Courses)
        {
            Console.WriteLine($"Course: {course.Name}, Code: {course.Code}");
        }
    }
}